public class principal {

    public static void main(String[] args) {

    }
}
