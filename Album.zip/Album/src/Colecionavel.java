import java.awt.*;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.TypeVariable;

public interface Colecionavel {

    Image getImagem();

    int getPosicao();

}
