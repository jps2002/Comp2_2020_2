public class TamanhoMaximoExcedidoException extends Exception {
}
