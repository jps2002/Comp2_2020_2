public class UsuarioDesconhecidoException extends Exception {
}
