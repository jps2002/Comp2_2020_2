public class UsuarioJaExisteException extends Exception {
}
